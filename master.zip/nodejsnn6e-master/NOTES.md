1. Fundamentals of Node JS 

Node.js is a JavaScript runtime built on Google Chrome's v8 JavaScript engine.

It uses an event-driven , non-blocking model that makes it lightweight and efficient. 

The node.js package ecosystem, npm (node package manager), is tge largest ecosystem of opensource libraries in the world. 

node.js is JavaScript running on the backend of server 

allows you to read, delete and update files (unlike javascript in the browser/frontend) 

easily communicate with databases

it's very fast 

great for real-time services (like chats and social media) 

2. Node.js web services 

Node.js Overview 
    - V8 Engine 
    
    - Modules
    http://www.tutorialsteacher.com/nodejs/nodejs-modules
    Node.js Module. Module in Node.js is a simple or complex functionality organized in single or multiple JavaScript files which can be reused throughout the Node.js application. Each module in Node.js has its own context, so it cannot interfere with other modules or pollute global scope.
    
    - Event Emitter 
    https://nodejs.org/api/events.html
    Node.js core API is based on asynchronous event-driven architecture in which certain kind of objects called emitters periodically emit events that cause listener objects to be called. All objects that emit events are members of EventEmitter class.

    - The File System 
    https://nodejs.org/api/fs.html#fs_file_system
    The fs module provides an API for interacting with the file system in a manner closely modeled around standard POSIX (unix) functions.

    To use this module:

    const fs = require('fs');
    
    Web Server
        -Routing (homework)
        https://medium.freecodecamp.org/really-really-basic-routing-in-nodejs-with-express-d7cad5e3f5d5
        -somewebsite.com/someroute
        -It’s basically taking the user (or some data) from one place to another. That place is the route. I told you I was going to make it quick.
        
        -Express
        https://en.wikipedia.org/wiki/Express.js
        Express.js, or simply Express, is a web application framework for Node.js, released as free and open-source software under the MIT License. It is designed for building web applications and APIs.[3] It has been called the de facto standard server framework for Node.js.
        
        It is designed for building web applications and APIs.[3] It has been called the de facto standard server framework for Node.js.[4]
        
        Express is the E in the MEAN stack (Mongo, Express, Angular, and Node)
        or MERN (Mongo, Express, React and Node)
        
        Express.js was foounded by TJ Holowaychuck on May 22, 2010 Version 0.12.0
        
        - Easy and flexible routing system
        - Integrates with many templating engines
        - Contains a middleware framework
        
        -Templating (homework) 
        
        
        
        
        
   
___________________________________________________________   
   
   URL list from Thursday, Jan. 3 2019 19:15 PM
To copy this list, type [Ctrl] A, then type [Ctrl] C. 

LisetteGorra/nodejsnn6e at version2.0
https://github.com/LisetteGorra/nodejsnn6e/tree/version2.0

Node JS Tutorial for Beginners #6 - Modules and require() - YouTube
https://www.youtube.com/watch?v=xHLd36QoS4k&list=PL4cUxeGkcC9gcy9lrvMJ75z9maRw4byYp&index=6

lgorra2018 - Cloud9
https://ide.c9.io/lgorra/lgorra2018

node js routing - Google Search
https://www.google.com/search?q=node+js+routing&rlz=1C5CHFA_enUS813US813&oq=node+js+routing&aqs=chrome..69i57l2j69i59l4.1831j0j8&sourceid=chrome&ie=UTF-8

Really, really basic routing in Node.js with Express
https://medium.freecodecamp.org/really-really-basic-routing-in-nodejs-with-express-d7cad5e3f5d5

node js express - Google Search
https://www.google.com/search?q=node+js+express&rlz=1C5CHFA_enUS813US813&oq=node+js+express&aqs=chrome.0.69i59l3j69i60j69i61j0.2096j0j8&sourceid=chrome&ie=UTF-8

Express - Node.js web application framework
https://expressjs.com/

Express/Node introduction | MDN
https://developer.mozilla.org/en-US/docs/Learn/Server-side/Express_Nodejs/Introduction

Express.js - Wikipedia
https://en.wikipedia.org/wiki/Express.js

tj holowaychuck - Google Search
https://www.google.com/search?q=tj+holowaychuck&rlz=1C5CHFA_enUS813US813&oq=tj+holowaychuck&aqs=chrome..69i57j0l5.6247j0j8&sourceid=chrome&ie=UTF-8
